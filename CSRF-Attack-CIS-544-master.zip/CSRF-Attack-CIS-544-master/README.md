# CSRF-Attack-CIS-544
Cross-Site Request Forgery (CSRF or XSRF)attack
CSRF Attack The objective of this project is to help students understand the Cross-Site Request Forgery (CSRF or XSRF) attack. A CSRF attack involves a victim user, a trusted site, and a malicious site. The victim user holds an active session with a trusted site while visiting a malicious site. The malicious site injects an HTTP request for the trusted site into the victim user session, causing damages.
In this project, you will be attacking a social networking web application using the CSRF attack. The open-source social networking application called Elgg has countermeasures against CSRF, but we have turned them off for the purpose of this project.

****You Need to download Virtual box according to Virtual Box Config file and config it. Then you're all set to roll :D
